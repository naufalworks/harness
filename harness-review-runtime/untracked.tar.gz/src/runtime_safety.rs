//! Runtime safety: tracked child processes and cooperative shutdown.
//!
//! Contract: the P10-T05 runtime half and the P14-T01 cancellation half. Two
//! bounded services live here and nowhere else:
//!
//! 1. **Child-process registry.** `bash` foreground commands and the diagnostics
//!    command run under `run_capped`, which puts each in its own process group.
//!    Detached `bash background` jobs are registered by the pid the shell prints.
//!    Every registered process group can be killed as a unit on cancellation or
//!    shutdown, so a turn cannot leave orphaned `sleep`/server processes behind.
//! 2. **Shutdown channel.** `request_shutdown` flips a `watch` value; the HTTP
//!    server, the SSE loops and the generation worker all observe it and stop at
//!    a safe point. Nothing is replayed: the durable rows are only ever marked
//!    `interrupted` after the fact by `recording::recover`.
//!
//! OS signals are intentionally *not* intercepted here. Catching SIGTERM needs
//! tokio's `signal` feature (a new transitive dependency); that is a dependency
//! change this worktree does not make without approval. `shutdown_signal` is the
//! single place to add it: today it resolves from the in-process channel, and a
//! future `tokio::signal::unix` handler only has to call `request_shutdown()`.
use std::collections::HashMap;
use std::process::Stdio;
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant};
use tokio::sync::watch;

/// One child process group the loop may have to stop. `step_id` is retained for
/// diagnostics and future per-step cancellation; `request_id` is what the
/// cancellation endpoint filters on today.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TrackedChild {
    pub pid: u32,
    pub request_id: String,
    #[allow(dead_code)]
    pub step_id: String,
}

static CHILDREN: OnceLock<Mutex<HashMap<u32, TrackedChild>>> = OnceLock::new();
fn children() -> &'static Mutex<HashMap<u32, TrackedChild>> {
    CHILDREN.get_or_init(|| Mutex::new(HashMap::new()))
}

/// Record a spawned child's process-group id. `pid == 0` is ignored so a failed
/// spawn can never make the registry believe it owns the whole process group.
pub fn register(pid: u32, request_id: &str, step_id: &str) {
    if pid == 0 {
        return;
    }
    children().lock().unwrap().insert(
        pid,
        TrackedChild {
            pid,
            request_id: request_id.to_string(),
            step_id: step_id.to_string(),
        },
    );
}

/// Forget a child that has exited normally. Idempotent.
pub fn unregister(pid: u32) {
    children().lock().unwrap().remove(&pid);
}

/// `/proc`-backed liveness with a conservative fallback: on a host without
/// `/proc` we assume a process is still alive rather than skip cleanup.
fn alive(pid: u32) -> bool {
    if std::path::Path::new("/proc").is_dir() {
        return std::path::Path::new(&format!("/proc/{pid}")).exists();
    }
    true
}

/// Live tracked children, pruning entries whose process already exited.
pub fn running() -> Vec<TrackedChild> {
    let mut guard = children().lock().unwrap();
    guard.retain(|pid, _| alive(*pid));
    guard.values().cloned().collect()
}

fn pids_for(request_id: Option<&str>) -> Vec<u32> {
    let mut guard = children().lock().unwrap();
    guard.retain(|pid, _| alive(*pid));
    guard
        .values()
        .filter(|c| request_id.map_or(true, |r| c.request_id == r))
        .map(|c| c.pid)
        .collect()
}

/// TERM then (if it survives) KILL a pid and its process group. The group is
/// targeted first so a shell's children die with it; the plain pid is a
/// best-effort fallback for a job that is not its own group leader.
fn signal(pid: u32, name: &str) {
    let _ = std::process::Command::new("sh")
        .arg("-c")
        .arg(format!(
            "kill -{name} -- -{pid} 2>/dev/null; kill -{name} -- {pid} 2>/dev/null"
        ))
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status();
}

fn wait_gone(pids: &[u32], grace: Duration) {
    let deadline = Instant::now() + grace;
    loop {
        if !pids.iter().any(|p| alive(*p)) || Instant::now() >= deadline {
            return;
        }
        std::thread::sleep(Duration::from_millis(25));
    }
}

/// Stop one child process group now: TERM, a short bounded wait, then KILL.
/// Always drops the registry entry, so a stale pid cannot be killed twice.
pub fn terminate(pid: u32) {
    signal(pid, "TERM");
    wait_gone(&[pid], Duration::from_millis(500));
    if alive(pid) {
        signal(pid, "KILL");
        wait_gone(&[pid], Duration::from_millis(500));
    }
    unregister(pid);
}

fn terminate_group(pids: Vec<u32>, grace: Duration) -> Vec<u32> {
    for pid in &pids {
        signal(*pid, "TERM");
    }
    wait_gone(&pids, grace);
    for pid in &pids {
        if alive(*pid) {
            signal(*pid, "KILL");
        }
        unregister(*pid);
    }
    pids
}

/// Stop every tracked child belonging to one cancelled request.
pub fn terminate_request(request_id: &str, grace: Duration) -> Vec<u32> {
    terminate_group(pids_for(Some(request_id)), grace)
}

/// Stop every tracked child. Called on shutdown.
pub fn terminate_all(grace: Duration) -> Vec<u32> {
    terminate_group(pids_for(None), grace)
}

// ---- Shutdown channel -------------------------------------------------------

static SHUTDOWN: OnceLock<watch::Sender<bool>> = OnceLock::new();
fn shutdown_tx() -> &'static watch::Sender<bool> {
    SHUTDOWN.get_or_init(|| watch::channel(false).0)
}

/// Flip the process into shutdown. Idempotent. Every waiter observes `true`.
pub fn request_shutdown() {
    let _ = shutdown_tx().send(true);
}

pub fn is_shutting_down() -> bool {
    *shutdown_tx().borrow()
}

pub fn subscribe() -> watch::Receiver<bool> {
    shutdown_tx().subscribe()
}

/// Resolves once shutdown is requested, either before this call or after it.
pub async fn shutdown_signal() {
    let mut rx = subscribe();
    loop {
        if *rx.borrow_and_update() {
            return;
        }
        if rx.changed().await.is_err() {
            return;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::os::unix::process::CommandExt;

    fn spawn_sleep(seconds: &str) -> std::process::Child {
        let mut cmd = std::process::Command::new("sh");
        cmd.arg("-c")
            .arg(format!("sleep {seconds}"))
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null());
        cmd.process_group(0);
        cmd.spawn().expect("spawn sleep")
    }

    #[test]
    fn registry_tracks_and_prunes_children() {
        let child = spawn_sleep("20");
        let pid = child.id();
        register(pid, "req-a", "step-1");
        assert!(running().iter().any(|c| c.pid == pid));
        unregister(pid);
        assert!(running().iter().all(|c| c.pid != pid));
        let _ = std::process::Command::new("sh")
            .arg("-c")
            .arg(format!("kill -9 -- -{pid} {pid} 2>/dev/null"))
            .status();
    }

    #[test]
    fn zero_pid_is_never_registered() {
        register(0, "req", "step");
        assert!(running().iter().all(|c| c.pid != 0));
    }

    #[test]
    fn terminate_kills_a_registered_process_group() {
        let child = spawn_sleep("30");
        let pid = child.id();
        register(pid, "req-a", "step-1");
        terminate(pid);
        assert!(!alive(pid), "pid {pid} should be gone after terminate");
        assert!(running().iter().all(|c| c.pid != pid));
    }

    #[test]
    fn terminate_request_only_touches_its_own_children() {
        let a = spawn_sleep("30");
        let b = spawn_sleep("30");
        register(a.id(), "req-a", "step-a");
        register(b.id(), "req-b", "step-b");
        let killed = terminate_request("req-a", Duration::from_millis(500));
        assert_eq!(killed, vec![a.id()]);
        assert!(!alive(a.id()));
        assert!(alive(b.id()), "an unrelated request's child must survive");
        terminate(b.id());
    }

    #[tokio::test]
    async fn shutdown_signal_resolves_after_request() {
        assert!(!is_shutting_down());
        request_shutdown();
        assert!(is_shutting_down());
        tokio::time::timeout(Duration::from_secs(2), shutdown_signal())
            .await
            .expect("shutdown_signal must resolve once requested");
    }
}
