//! Structured command policy (P13-T03, minimal slice).
//!
//! The historical behaviour is a deny-list (`is_dangerous_command`) that forces
//! approval even in `auto_all`. This module adds two *opt-in* command classes —
//! outbound network use and package installation — that can be made to `ask`
//! (always require approval) or `deny` (refuse outright):
//!
//! * `HARNESS_COMMAND_NETWORK_POLICY=off|ask|deny` (default `off`)
//! * `HARNESS_COMMAND_INSTALL_POLICY=off|ask|deny` (default `off`)
//!
//! With both unset the module is a no-op and `requires_permission` keeps the old
//! behaviour exactly. A value that is not one of the three words is a startup
//! error, so a typo cannot silently turn a policy the operator asked for back off
//! (fail closed).
//!
//! Detection is deliberately conservative and *never* inspects the arguments of
//! an unrelated program: it classifies each `;`/`|`/`&&` segment by its program
//! (after dropping `VAR=value` assignments and `sudo`/`env`-style wrappers) and,
//! for a small set of multi-verb programs (`git`, package managers), by the
//! subcommand word. So `grep curl notes.txt` is not network use, while
//! `FOO=1 sudo curl -s url` is.
use std::sync::OnceLock;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NetworkPolicy {
    Off,
    Ask,
    Deny,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum InstallPolicy {
    Off,
    Ask,
    Deny,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CommandPolicy {
    pub network: NetworkPolicy,
    pub install: InstallPolicy,
}

impl Default for CommandPolicy {
    fn default() -> Self {
        Self {
            network: NetworkPolicy::Off,
            install: InstallPolicy::Off,
        }
    }
}

fn parse<T: Copy>(key: &str, value: Option<&str>, off: T, ask: T, deny: T) -> Result<T, String> {
    match value.map(str::trim) {
        None | Some("") | Some("off") => Ok(off),
        Some("ask") => Ok(ask),
        Some("deny") => Ok(deny),
        Some(other) => Err(format!("{key} must be one of off|ask|deny, not {other:?}")),
    }
}

impl CommandPolicy {
    pub fn disabled() -> Self {
        Self::default()
    }

    /// Build from already-read values so the decision logic is testable without
    /// touching process-global environment variables.
    pub fn from_values(network: Option<&str>, install: Option<&str>) -> Result<Self, String> {
        Ok(Self {
            network: parse(
                "HARNESS_COMMAND_NETWORK_POLICY",
                network,
                NetworkPolicy::Off,
                NetworkPolicy::Ask,
                NetworkPolicy::Deny,
            )?,
            install: parse(
                "HARNESS_COMMAND_INSTALL_POLICY",
                install,
                InstallPolicy::Off,
                InstallPolicy::Ask,
                InstallPolicy::Deny,
            )?,
        })
    }

    pub fn from_env() -> Result<Self, String> {
        let network = std::env::var("HARNESS_COMMAND_NETWORK_POLICY").ok();
        let install = std::env::var("HARNESS_COMMAND_INSTALL_POLICY").ok();
        Self::from_values(network.as_deref(), install.as_deref())
    }

    /// Classes the policy actually enforces for this command; used in the
    /// permission payload so the UI can explain why approval is required.
    pub fn classes(&self, command: &str) -> Vec<&'static str> {
        let mut out = Vec::new();
        if self.network != NetworkPolicy::Off && uses_network(command) {
            out.push("network");
        }
        if self.install != InstallPolicy::Off && installs_packages(command) {
            out.push("install");
        }
        out
    }

    /// Reason the command must be approved even in `auto_all`.
    pub fn escalation(&self, command: &str) -> Option<&'static str> {
        if self.network == NetworkPolicy::Ask && uses_network(command) {
            return Some("network");
        }
        if self.install == InstallPolicy::Ask && installs_packages(command) {
            return Some("install");
        }
        None
    }

    /// Reason the command must be refused regardless of mode or approval.
    pub fn refusal(&self, command: &str) -> Option<&'static str> {
        if self.network == NetworkPolicy::Deny && uses_network(command) {
            return Some("network");
        }
        if self.install == InstallPolicy::Deny && installs_packages(command) {
            return Some("install");
        }
        None
    }
}

static CURRENT: OnceLock<CommandPolicy> = OnceLock::new();

/// Install the process-wide policy. Call once during startup, before any turn
/// can run; a policy that failed to parse must not be installed at all.
pub fn install(policy: CommandPolicy) {
    let _ = CURRENT.set(policy);
}

/// The active policy, or the disabled default if none was installed.
pub fn current() -> &'static CommandPolicy {
    CURRENT.get_or_init(CommandPolicy::disabled)
}

// ---- classification ---------------------------------------------------------

const NETWORK_PROGRAMS: &[&str] = &[
    "curl", "wget", "nc", "ncat", "netcat", "telnet", "ftp", "ssh", "scp", "sftp", "rsync", "ping",
    "ping6", "dig", "nslookup", "host", "traceroute", "tracert", "socat", "aria2c", "http",
    "httpie", "gh",
];
const PACKAGE_MANAGERS: &[&str] = &[
    "pip", "pip3", "pipx", "npm", "npx", "yarn", "pnpm", "cargo", "go", "apt", "apt-get", "yum",
    "dnf", "pacman", "brew", "snap", "gem", "composer", "poetry", "conda", "mamba", "rustup",
    "deno", "uv",
];
const INSTALL_VERBS: &[&str] = &[
    "install",
    "i",
    "add",
    "get",
    "download",
    "publish",
    "update",
    "upgrade",
    "remove",
    "uninstall",
    "dist-upgrade",
    "autoremove",
    "sync",
];
const WRAPPERS: &[&str] = &[
    "env", "sudo", "doas", "nohup", "time", "command", "builtin", "exec", "setsid",
];

/// Split into shell segments (`;`, `|`, `&&`, `||`) and drop leading
/// `VAR=value` assignments and wrapper programs with their flags. The first
/// remaining word is the segment's program; the rest are kept for multi-verb
/// classification. Quoting is not parsed on purpose — this only ever inspects
/// the program position, not another program's arguments.
fn segments(command: &str) -> Vec<Vec<String>> {
    let mut out = Vec::new();
    for raw in command.split(|c| c == ';' || c == '|' || c == '&') {
        let mut tokens: Vec<String> = raw.split_whitespace().map(strip_quotes).collect();
        while tokens.first().map(|t| is_assignment(t)).unwrap_or(false) {
            tokens.remove(0);
        }
        loop {
            let Some(first) = tokens.first() else { break };
            if WRAPPERS.contains(&basename(first).as_str()) {
                tokens.remove(0);
                while tokens.first().map(|t| t.starts_with('-')).unwrap_or(false) {
                    tokens.remove(0);
                }
            } else {
                break;
            }
        }
        if !tokens.is_empty() {
            out.push(tokens);
        }
    }
    out
}

fn strip_quotes(token: &str) -> String {
    token.trim_matches(|c| c == '\'' || c == '"').to_string()
}

fn basename(token: &str) -> String {
    token.rsplit('/').next().unwrap_or(token).to_string()
}

fn is_assignment(token: &str) -> bool {
    let Some((name, _)) = token.split_once('=') else {
        return false;
    };
    !name.is_empty()
        && name.len() <= 64
        && name
            .chars()
            .enumerate()
            .all(|(i, c)| c == '_' || c.is_ascii_alphabetic() || (i > 0 && c.is_ascii_digit()))
}

fn uses_network(command: &str) -> bool {
    for segment in segments(command) {
        let Some(program) = segment.first() else {
            continue;
        };
        let name = basename(program);
        if NETWORK_PROGRAMS.contains(&name.as_str()) {
            return true;
        }
        let args = &segment[1..];
        if name == "git" {
            if args.iter().any(|a| {
                matches!(
                    a.as_str(),
                    "push"
                        | "fetch"
                        | "pull"
                        | "clone"
                        | "remote"
                        | "ls-remote"
                        | "submodule"
                        | "archive"
                )
            }) {
                return true;
            }
        }
        if PACKAGE_MANAGERS.contains(&name.as_str())
            && args.iter().any(|a| INSTALL_VERBS.contains(&a.as_str()))
        {
            return true;
        }
    }
    false
}

fn installs_packages(command: &str) -> bool {
    for segment in segments(command) {
        let Some(program) = segment.first() else {
            continue;
        };
        let name = basename(program);
        if PACKAGE_MANAGERS.contains(&name.as_str())
            && segment[1..].iter().any(|a| INSTALL_VERBS.contains(&a.as_str()))
        {
            return true;
        }
    }
    false
}

#[cfg(test)]
mod tests {
    use super::*;

    fn policy(network: NetworkPolicy, install: InstallPolicy) -> CommandPolicy {
        CommandPolicy { network, install }
    }

    #[test]
    fn disabled_policy_never_escalates_or_refuses() {
        let p = CommandPolicy::disabled();
        for cmd in ["curl https://example.com", "npm install left-pad", "rm -rf /"] {
            assert_eq!(p.escalation(cmd), None, "{cmd}");
            assert_eq!(p.refusal(cmd), None, "{cmd}");
            assert!(p.classes(cmd).is_empty(), "{cmd}");
        }
    }

    #[test]
    fn network_ask_escalates_but_deny_refuses() {
        let ask = policy(NetworkPolicy::Ask, InstallPolicy::Off);
        assert_eq!(ask.escalation("curl https://example.com"), Some("network"));
        assert_eq!(ask.refusal("curl https://example.com"), None);
        assert_eq!(ask.classes("wget -q url"), vec!["network"]);

        let deny = policy(NetworkPolicy::Deny, InstallPolicy::Off);
        assert_eq!(deny.refusal("ssh host"), Some("network"));
        assert_eq!(deny.escalation("ssh host"), None);
    }

    #[test]
    fn install_class_is_independent_of_network_class() {
        let p = policy(NetworkPolicy::Off, InstallPolicy::Ask);
        assert_eq!(p.escalation("cargo install ripgrep"), Some("install"));
        assert_eq!(p.classes("cargo install ripgrep"), vec!["install"]);
        // A read-only cargo invocation is not an install.
        assert_eq!(p.escalation("cargo test"), None);
    }

    #[test]
    fn assignments_and_wrappers_do_not_hide_network_use() {
        let p = policy(NetworkPolicy::Ask, InstallPolicy::Off);
        assert_eq!(p.escalation("FOO=1 curl url"), Some("network"));
        assert_eq!(p.escalation("sudo -u root curl url"), Some("network"));
        assert_eq!(p.escalation("cd /tmp && git fetch origin"), Some("network"));
        assert_eq!(p.escalation("echo hi | nc host 80"), Some("network"));
    }

    #[test]
    fn arguments_of_other_programs_are_not_misclassified() {
        let p = policy(NetworkPolicy::Ask, InstallPolicy::Ask);
        assert_eq!(p.escalation("grep curl notes.txt"), None);
        assert_eq!(p.escalation("echo npm install"), None);
        assert_eq!(p.escalation("rg 'wget|curl' src"), None);
        assert_eq!(p.escalation("cargo build --locked"), None);
        assert_eq!(p.escalation("git status"), None);
    }

    #[test]
    fn invalid_policy_values_fail_closed() {
        assert!(CommandPolicy::from_values(Some("sometimes"), None).is_err());
        assert!(CommandPolicy::from_values(None, Some("denyy")).is_err());
        assert_eq!(
            CommandPolicy::from_values(Some("deny"), Some("ask")).unwrap(),
            policy(NetworkPolicy::Deny, InstallPolicy::Ask)
        );
        assert_eq!(
            CommandPolicy::from_values(None, Some("")).unwrap(),
            CommandPolicy::disabled()
        );
    }
}
